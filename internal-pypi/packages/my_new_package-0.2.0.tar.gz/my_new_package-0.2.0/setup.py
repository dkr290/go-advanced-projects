from setuptools import setup, find_packages

setup(
    name="my_new_package",
    version="0.2.0",  # Update this version for each release
    packages=find_packages(),
    description="A simple example package",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://example.com/my_package",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

